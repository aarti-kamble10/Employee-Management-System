package com.Springboot.curdMVC.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.Springboot.curdMVC.entity.Employee;
import com.Springboot.curdMVC.service.EmployeeService;

@Controller
public class EmployeeController {
	
	private EmployeeService employeeSer;

	public EmployeeController(EmployeeService employeeSer) {
		super();
		this.employeeSer = employeeSer;
	}
	
	@GetMapping("/GetEmployee")
	public String listEmployee(Model mod)
	{
		mod.addAttribute("employee",employeeSer.getAllEmployee());
		return "employees";
	}
	
	@GetMapping("/Employee/New")
	public String CreateEmployee(Model mod)
	{		Employee employee= new Employee();
	    mod.addAttribute("employee", employee);
	    return "create_employee";
		
	}
	
	@PostMapping("/Employee/save")
	public String saveEmployee(@ModelAttribute("employee") Employee employee)
	{
		employeeSer.saveEmployee(employee);
		
		return "redirect:/GetEmployee";
	}
	
	@GetMapping("/Employee/edit/{id}")
	public String editEmployeeForm(@PathVariable long id , Model mod)
	{
		mod.addAttribute("employee", employeeSer.getEmployeeById(id));
		return "edit_employee";
		
	}
	
	@PostMapping("/Employee/update/{id}")
	public String updateEmployee(@PathVariable long id , @ModelAttribute("employee") Employee employee , Model mod)
	{
		Employee existingEmployee = employeeSer.getEmployeeById(id);
		existingEmployee.setId(id);
		existingEmployee.setFirstname(employee.getFirstname());
		existingEmployee.setLastname(employee.getLastname());
		existingEmployee.setEmail(employee.getEmail());
		employeeSer.saveEmployee(existingEmployee);
		return "redirect:/GetEmployee";
		
	}

	@GetMapping("/Employee/delete/{id}")
	public String deleteEmployee(@PathVariable long id )
	{
		employeeSer.deleteEmployeeById(id);
		return "redirect:/GetEmployee";
		
	}

}
