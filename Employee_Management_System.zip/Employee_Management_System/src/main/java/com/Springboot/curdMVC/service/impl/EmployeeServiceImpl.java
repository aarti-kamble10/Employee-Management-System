package com.Springboot.curdMVC.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Springboot.curdMVC.entity.Employee;
import com.Springboot.curdMVC.repository.EmployeeRepository;
import com.Springboot.curdMVC.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeRepository employeerepo;
	
	public EmployeeServiceImpl(EmployeeRepository employeerepo) {
		super();
		this.employeerepo = employeerepo;
	}

	@Override
	public List<Employee> getAllEmployee() {
		
		return employeerepo.findAll();
	}

	@Override
	public Employee saveEmployee(Employee employee) {
		
		return employeerepo.save(employee);
		
	}

	@Override
	public Employee getEmployeeById(long id) {
		
		return employeerepo.findById(id).get();
	}

	@Override
	public void deleteEmployeeById(long id) {
		
		employeerepo.deleteById(id);
		
	}

	

}
