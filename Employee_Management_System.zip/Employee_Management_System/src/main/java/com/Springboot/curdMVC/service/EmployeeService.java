package com.Springboot.curdMVC.service;

import java.util.List;

import com.Springboot.curdMVC.entity.Employee;

public interface EmployeeService {
	
	List<Employee> getAllEmployee();
	
Employee saveEmployee(Employee employee);
	
	Employee getEmployeeById(long id);
	
	void deleteEmployeeById(long id);
	

}
